/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author Vini_
 */
public class Comum extends Usuario{
    private boolean valeTransporte;

    public Comum(boolean valeTransporte, String cpf, String nome, String endereco, String cidade, String telefone, String tipo) {
        super(cpf, nome, endereco, cidade, telefone, tipo);
        this.valeTransporte = valeTransporte;
    }

    public boolean isValeTransporte() {
        return valeTransporte;
    }

    public void setValeTransporte(boolean valeTransporte) {
        this.valeTransporte = valeTransporte;
    }
    
}
