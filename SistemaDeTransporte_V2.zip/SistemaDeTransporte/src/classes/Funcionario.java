/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author barbara
 */
public class Funcionario extends Usuario{
    private String cargo;
    private double salario;

    public Funcionario(String cargo, double salario, String cpf, String usuario, String senha, String nome, String endereco, String cidade, String telefone, String tipo) {
        super(cpf, usuario, senha, nome, endereco, cidade, telefone, tipo);
        this.cargo = cargo;
        this.salario = salario;
    }


    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
}
