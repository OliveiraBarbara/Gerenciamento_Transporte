/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author barbara
 */
public class Motorista extends Funcionario{

    public Motorista(String cargo, double salario, String cpf, String usuario, String senha, String nome, String endereco, String cidade, String telefone, String tipo) {
        super(cargo, salario, cpf, usuario, senha, nome, endereco, cidade, telefone, tipo);
    }
    
}
