/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operacoes;

import classes.Estudante;
import classes.Idoso;
import classes.Usuario;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Vini_
 */
public class CadastroUsuarioOperacao {

    public static boolean cadastroUsuario(String cpf, String usuarioLogin, String senha, String nome, String endereco, String cidade, String telefone, String tipo, ArrayList<Usuario> usuarios) throws ParseException {
        boolean resposta = false;
        switch (tipo.toLowerCase()) {
            case "idoso":
                String dataNasc = JOptionPane.showInputDialog(null, "Informe a data de nascimento", "Data de nascimento", JOptionPane.OK_CANCEL_OPTION);
                if (dataNasc != null) {
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                    Idoso idoso = new Idoso(formatter.parse(dataNasc), cpf,usuarioLogin, senha, nome, endereco, cidade, telefone, tipo);
                    System.out.println(formatter.format(idoso.getDataNasc()));
                    usuarios.add(idoso);
                    resposta = true;
                }

                break;
            case "estudante":
                String localEstudo = JOptionPane.showInputDialog(null, "Informe a instituição de ensino", "Instituição de ensino", JOptionPane.OK_CANCEL_OPTION);
                String matricula;
                if (localEstudo != null) {
                    matricula = JOptionPane.showInputDialog(null, "Informe a instituição de ensino", "Instituição de ensino", JOptionPane.OK_CANCEL_OPTION);
                    if (matricula != null) {
                        Estudante estudante = new Estudante(Integer.parseInt(matricula), localEstudo, cpf,usuarioLogin, senha, nome, endereco, cidade, telefone, tipo);
                        usuarios.add(estudante);
                        resposta = true;
                    }
                }

                break;
            case "comum":
                Usuario usuario = new Usuario(cpf, usuarioLogin, senha, nome, endereco, cidade, telefone, tipo);
                resposta = true;
                usuarios.add(usuario);
                break;
            default:
                JOptionPane.showConfirmDialog(null, "Tipo de usuário invalido!", "Atenção!", JOptionPane.WARNING_MESSAGE);
                break;
        }
        return resposta;
    }
}
